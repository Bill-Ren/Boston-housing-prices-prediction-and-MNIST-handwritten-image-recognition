# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import os
import sys
sys.version

from sklearn import svm

import numpy as np#引入矩阵运算库
import struct#引入数据处理模块
import matplotlib.pyplot as plt#引用绘图库
import time
ret=[]

# 训练集文件
train_images_idx3_ubyte_file = 'train-images.idx3-ubyte'
# 训练集标签文件
train_labels_idx1_ubyte_file = 'train-labels.idx1-ubyte'

# 测试集文件
test_images_idx3_ubyte_file = 't10k-images.idx3-ubyte'
# 测试集标签文件
test_labels_idx1_ubyte_file = 't10k-labels.idx1-ubyte'


def decode_idx3_ubyte(idx3_ubyte_file):#解析图像文件

    # 读取二进制数据
    bin_data = open(idx3_ubyte_file, 'rb').read()

    # 解析文件头信息，依次为魔数、图片数量、每张图片高、每张图片宽
    offset = 0
    fmt_header = '>iiii' #因为数据结构中前4行的数据类型都是32位整型，所以采用i格式，但我们需要读取前4行数据，所以需要4个i。
    magic_number, num_images, num_rows, num_cols = struct.unpack_from(fmt_header, bin_data, offset)
    print('魔数:%d, 图片数量: %d张, 图片大小: %d*%d' % (magic_number, num_images, num_rows, num_cols))

    # 解析数据集
    image_size = num_rows * num_cols
    offset += struct.calcsize(fmt_header)  #获得数据在缓存中的指针位置，从前面介绍的数据结构可以看出，读取了前4行之后，指针位置（即偏移位置offset）指向0016。
    print('偏置位置:%d'%(offset))
    fmt_image = '>' + str(image_size) + 'B'  #图像数据像素值的类型为unsigned char型，对应的format格式为B。这里还有加上图像大小784，是为了读取784个B格式数据，如果没有则只会读取一个值（即一副图像中的一个像素值）, '>784B'的意思就是用大端法读取784个unsigned byte
    print(fmt_image,offset,struct.calcsize(fmt_image))
    images = np.empty((num_images, num_rows, num_cols))#建立通过二进制文件解析过来的数据
    plt.figure()

    for i in range(num_images):
        if (i + 1) % 10000 == 0:
            print('已解析 %d' % (i + 1) + '张')
            print(offset)
        images[i] = np.array(struct.unpack_from(fmt_image, bin_data, offset)).reshape((num_rows, num_cols))
    
        offset += struct.calcsize(fmt_image)
        # plt.imshow(images[i],'gray')
        # plt.pause(0.00001)
        # plt.show()
        # plt.show()
    return images

def decode_idx1_ubyte(idx1_ubyte_file):#解析标志文件
    # 读取二进制数据
    bin_data = open(idx1_ubyte_file, 'rb').read()
    # 解析文件头信息，依次为魔数和标签数
    offset = 0
    fmt_header = '>ii'#因为数据结构中前4行的数据类型都是32位整型，所以采用i格式，但我们需要读取前2行数据，所以需要2个i。
    magic_number, num_images = struct.unpack_from(fmt_header, bin_data, offset)
    print('魔数:%d, 图片数量: %d张' % (magic_number, num_images))

    # 解析数据集
    offset += struct.calcsize(fmt_header)
    fmt_image = '>B'
    labels = np.empty(num_images)
    for i in range(num_images):
        if (i + 1) % 10000 == 0:
            print ('已解析 %d' % (i + 1) + '张')
        labels[i] = struct.unpack_from(fmt_image, bin_data, offset)[0]
        offset += struct.calcsize(fmt_image)
    return labels


def load_train_images(idx_ubyte_file=train_images_idx3_ubyte_file):#加载训练图片文件
    return decode_idx3_ubyte(idx_ubyte_file)


def load_train_labels(idx_ubyte_file=train_labels_idx1_ubyte_file):#加载训练集标志文件
    return decode_idx1_ubyte(idx_ubyte_file)


def load_test_images(idx_ubyte_file=test_images_idx3_ubyte_file):#加载测试集图片文件
    return decode_idx3_ubyte(idx_ubyte_file)


def load_test_labels(idx_ubyte_file=test_labels_idx1_ubyte_file):#加载测试集标志文件
    return decode_idx1_ubyte(idx_ubyte_file)



if __name__ == '__main__':
    start=time.time()
    class_right = 0
    class_wrong = 0
    print("start")
    train_images = load_train_images()#加载训练图像矩阵
    train_labels = load_train_labels()#加载训练标志
    test_images = load_test_images()#加载测试图像矩阵
    test_labels = load_test_labels()#加载测试标志
    train_data = np.random.rand(len(train_images),784)
    test_data = np.random.rand(len(test_images),784)
    print('验证数据')
    print(len(train_images[1]))
    print(len(train_images))
    print(len(test_images))
    print(test_images[1,1])
    #训练集转化为特征向量
    for i in range (len(train_images)):
        a = []
        for j in range (len(train_images[1])):
            a = a + list(train_images[i][j])
        train_data[i,:] = a
    print("step1")
    #测试集转化为特征向量
    for i in range (len(test_images)):
        b = []
        for j in range (len(test_images[1])):
            b = b + list(test_images[i][j])
        test_data[i,:] = b
    clf = svm.SVC( probability=True)
    clf.fit (list(train_data) ,list(train_labels))
    predict=clf.predict(list(test_data))
    print("step2")
    for i in range(len(test_images)):
        if predict[i] == test_labels[i]:
            class_right +=1
            # print (class_right)
        else:
            class_wrong +=1
            print('分类错误信息：\n','预测值：',predict[i],'真实值：',test_labels[i])
            plt.imshow(test_images[i],cmap='gray')
            plt.pause(0.000001)
            plt.show()
    end = time.time()    
        #print('正确:',class_right,'\n错误:',class_wrong)
    print('分类正确的数量为：\n',class_right)
    print('分类错误的数量为：\n',class_wrong)
    print('分类准确率为： \n',class_right/100,'%')
    print('运行时间为：',end-start)
