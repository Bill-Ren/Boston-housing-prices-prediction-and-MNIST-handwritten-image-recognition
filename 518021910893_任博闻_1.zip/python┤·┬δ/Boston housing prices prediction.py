#!/usr/local/bin/python3
import numpy as np
np.set_printoptions(threshold=np.inf)
import pandas as pd
pd.set_option('display.width', 1000)  # 设置字符显示宽度
pd.set_option('display.max_rows', None)  # 设置显示最大行
pd.set_option('display.max_columns', None)  # 设置显示最大行
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from numpy import arange
from matplotlib import pyplot
from pandas import read_csv
from pandas import  set_option
from pandas.plotting import scatter_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import ElasticNet
from sklearn.svm import SVR
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_regression


def testHouse():
    # 读取房屋数据集
    data = pd.read_csv("house_data.csv")
    # 描述性统计信息
    set_option('precision', 1)
    information=data.describe()
    print(information)

    #提取特征和标记
    prices = data['MEDV']
    features = data.drop('MEDV', axis=1)

    # 查看各个特征的散点分布
    scatter_matrix(data, alpha=0.7, figsize=(10, 10), diagonal='kde')
    pyplot.show()

def featureSelection():
    data = pd.read_csv("house_data.csv")
    x = data[['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD', 'TAX',
              'PTRATIO', 'B', 'LSTAT']]
    # print(x.head())
    y = data['MEDV']
    #选取三个最佳特征
    # from sklearn.feature_selection import SelectKBest
    # import matplotlib.pyplot as plt
    # SelectKBest = SelectKBest(f_regression, k=3)
    # bestFeature = SelectKBest.fit_transform(x, y)
    # SelectKBest.get_support(indices=False)
    #
    # # print(SelectKBest.transform(x))
    # #打印选取的最佳三个特征
    # print(x.columns[SelectKBest.get_support(indices=False)])
    #
    # #绘制三个特征原始数据的散点图
    # features = data[['RM', 'PTRATIO', 'LSTAT']].copy()
    # pd.plotting.scatter_matrix(features, alpha=0.7, figsize=(6, 6), diagonal='hist')
    # pyplot.show()
    # #将三个特征的数据归一化
    # from sklearn.preprocessing import MinMaxScaler
    # scaler = MinMaxScaler()
    # for feature in features.columns:
    #     features.loc[:, 'Standardized_' + feature] = scaler.fit_transform(features[[feature]])
    #
    # # 散点可视化，查看特征归一化后的数据
    # font = {
    #     'family': 'SimHei'
    # }
    # pyplot.rc('font', **font)
    # #查看归一化的数据
    # pd.plotting.scatter_matrix(features[['Standardized_RM', 'Standardized_PTRATIO', 'Standardized_LSTAT']], alpha=0.7, figsize=(6, 6),diagonal='hist')
    # pyplot.show()
    #
    # # 数据集拆分
    # x_train, x_test, y_train, y_test = train_test_split(
    #     features[['Standardized_RM', 'Standardized_PTRATIO', 'Standardized_LSTAT']], y,
    #     test_size=0.5, random_state=0)
    # # random_state 表示是否随机划分训练集与测试集，若ransom_state=0，则会随机划分测试集与训练集。

    #选取所有的特征进行回归分析
    features = data.drop('MEDV', axis=1)
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()
    # 数据集拆分
    for feature in features.columns:
        features.loc[:, '标准化' + feature] = scaler.fit_transform(features[[feature]])

    x_train, x_test, y_train, y_test = train_test_split(features, y,
                                                        test_size=0.8, random_state=0)

    # 线性模型拟合
    model = LinearRegression()
    model.fit(x_train, y_train)
    # plt.plot(x_train, y_train, linewidth=2)
    # 预测结果
    result = model.predict(x_test)

    # print(y_test-result)
    error=(abs(result-y_test))/y_test
    avg=sum(error)/len(error)
    print("平均误差")  # 预测结果
    print(avg)
def main():
    testHouse()
    featureSelection()
if __name__ == "__main__":
    main()