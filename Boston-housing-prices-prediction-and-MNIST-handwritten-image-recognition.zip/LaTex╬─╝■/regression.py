#!/usr/local/bin/python3
import numpy as np
np.set_printoptions(threshold=np.inf)
import pandas as pd
pd.set_option('display.width', 1000)  # Set character display width
pd.set_option('display.max_rows', None)  # Set the display maximum line
pd.set_option('display.max_columns', None)  #Set the display maximum line
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from numpy import arange
from matplotlib import pyplot
from pandas import read_csv
from pandas import  set_option
from pandas.plotting import scatter_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import ElasticNet
from sklearn.svm import SVR
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_regression


def testHouse():
    # Read house data set
    data = pd.read_csv("house_data.csv")
    # Descriptive statistics
    set_option('precision', 1)
    information=data.describe()
    print(information)

    #Extract features and tags
    prices = data['MEDV']
    features = data.drop('MEDV', axis=1)

    # View the scatter distribution of each feature
    scatter_matrix(data, alpha=0.7, figsize=(10, 10), diagonal='kde')
    pyplot.show()

def featureSelection():
    data = pd.read_csv("house_data.csv")
    x = data[['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD', 'TAX',
              'PTRATIO', 'B', 'LSTAT']]
    # print(x.head())
    y = data['MEDV']
    #Pick the three best features
    from sklearn.feature_selection import SelectKBest
    import matplotlib.pyplot as plt
    SelectKBest = SelectKBest(f_regression, k=3)
    bestFeature = SelectKBest.fit_transform(x, y)
    SelectKBest.get_support(indices=False)

    # print(SelectKBest.transform(x))
    #Print the best three selected features
    print(x.columns[SelectKBest.get_support(indices=False)])

    #Plot the scatterplot of the three feature raw data
    features = data[['RM', 'PTRATIO', 'LSTAT']].copy()
    pd.plotting.scatter_matrix(features, alpha=0.7, figsize=(6, 6), diagonal='hist')
    pyplot.show()
    #Normalize the data of the three features
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()
    for feature in features.columns:
        features.loc[:, 'Standardized_' + feature] = scaler.fit_transform(features[[feature]])

    # Scatter visualization, view the data after normalization of features
    font = {
        'family': 'SimHei'
    }
    pyplot.rc('font', **font)
    #View normalized data
    pd.plotting.scatter_matrix(features[['Standardized_RM', 'Standardized_PTRATIO', 'Standardized_LSTAT']], alpha=0.7, figsize=(6, 6),diagonal='hist')
    pyplot.show()

    # Data set split
    x_train, x_test, y_train, y_test = train_test_split(
        features[['Standardized_RM', 'Standardized_PTRATIO', 'Standardized_LSTAT']], y,
        test_size=0.5, random_state=0)
    # random_state 表示是否随机划分训练集与测试集，若ransom_state=0，则会随机划分测试集与训练集。

    #Select all features for regression analysis
    # features = data.drop('MEDV', axis=1)
    # from sklearn.preprocessing import MinMaxScaler
    # scaler = MinMaxScaler()
    #Data set split
    # for feature in features.columns:
    #     features.loc[:, '标准化' + feature] = scaler.fit_transform(features[[feature]])
    #
    # x_train, x_test, y_train, y_test = train_test_split(features, y,
    #                                                     test_size=0.8, random_state=0)

    # Linear model fitting
    model = LinearRegression()
    model.fit(x_train, y_train)
    # plt.plot(x_train, y_train, linewidth=2)
    # forecast result
    result = model.predict(x_test)

    # print(y_test-result)
    error=(abs(result-y_test))/y_test
    avg=sum(error)/len(error)
    print("平均误差")
    print(avg)
def main():
    testHouse()
    featureSelection()

if __name__ == "__main__":
    main()